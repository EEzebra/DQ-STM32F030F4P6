#ifndef   _MyType_H
#define   _MyType_H

#ifndef BIT
#define BIT(x)	(1 << (x))
#endif



#endif


